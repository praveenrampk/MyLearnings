import { useState } from 'react';
import './App.css';

const App =_=> {
  const [list, setList] = useState([
    {
      name: 'chat [BL]',
      url: 'https://mail.google.com/chat/u/3/#chat/welcome',
    }, 
    {
      name: 'chat [ET]',
      url: 'https://mail.google.com/chat/u/0/#chat/welcome',
    },
    {
      name: 'gmail',
      url: 'https://mail.google.com/mail/u/3/#inbox',
    }
  ]);

  return (
    <div className='App'>
      <h3>choose your App List</h3>
      <div className='lists'>
        { list && list.map((item) => {
          return (
            <div>
              <button className='button' onClick={() => window.open(item.url)}>{item.name}</button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
export default App;